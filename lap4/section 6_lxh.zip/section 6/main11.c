#include <stdio.h>
void main()
{
 char item[20];
 int partno;
 float cost;
 scanf("%s %*d %f",&item, &partno, &cost);
}