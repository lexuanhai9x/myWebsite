#include <stdio.h>
void main()
{
 char letter;
 printf("You can enter a character now: ");
 letter = getchar();
 putchar(letter);
}