#include <stdio.h>
#include <conio.h>
void main()
{
 int a = 10;
 float b = 24.67892345;
 char ch = 'A';
 printf("Integer data = %d\n", a);
 printf("Float Data = %f\n",b);
 printf("Character = %c\n",ch);
 printf("This prints the string\n");
 printf("%s","This also prints a string");
}