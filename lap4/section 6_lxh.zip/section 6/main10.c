#include <stdio.h>
void main()
{
 char line[80];
 scanf("%[^\n]",line);

 printf("%s",line);
}